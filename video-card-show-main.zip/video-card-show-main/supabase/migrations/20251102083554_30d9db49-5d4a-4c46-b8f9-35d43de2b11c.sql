-- Create storage bucket for post thumbnails
INSERT INTO storage.buckets (id, name, public)
VALUES ('post-thumbnails', 'post-thumbnails', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for post-thumbnails bucket
-- Anyone can view thumbnails (public bucket)
CREATE POLICY "Anyone can view thumbnails"
ON storage.objects
FOR SELECT
USING (bucket_id = 'post-thumbnails');

-- Only admins can upload thumbnails
CREATE POLICY "Admins can upload thumbnails"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'post-thumbnails' AND
  EXISTS (
    SELECT 1 FROM public.admins WHERE id = auth.uid()
  )
);

-- Only admins can update thumbnails
CREATE POLICY "Admins can update thumbnails"
ON storage.objects
FOR UPDATE
USING (
  bucket_id = 'post-thumbnails' AND
  EXISTS (
    SELECT 1 FROM public.admins WHERE id = auth.uid()
  )
);

-- Only admins can delete thumbnails
CREATE POLICY "Admins can delete thumbnails"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'post-thumbnails' AND
  EXISTS (
    SELECT 1 FROM public.admins WHERE id = auth.uid()
  )
);