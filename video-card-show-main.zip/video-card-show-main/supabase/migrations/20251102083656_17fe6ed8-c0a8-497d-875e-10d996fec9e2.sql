-- Fix search_path for all functions to prevent security issues

-- Update generate_slug function
CREATE OR REPLACE FUNCTION public.generate_slug(title text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  slug TEXT;
  counter INT := 0;
  temp_slug TEXT;
BEGIN
  slug := LOWER(REGEXP_REPLACE(title, '[^a-zA-Z0-9]+', '-', 'g'));
  slug := TRIM(BOTH '-' FROM slug);
  
  temp_slug := slug;
  WHILE EXISTS (SELECT 1 FROM public.posts WHERE posts.slug = temp_slug) LOOP
    counter := counter + 1;
    temp_slug := slug || '-' || counter;
  END LOOP;
  
  RETURN temp_slug;
END;
$$;

-- Update set_post_slug function
CREATE OR REPLACE FUNCTION public.set_post_slug()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.slug IS NULL OR NEW.slug = '' THEN
    NEW.slug := public.generate_slug(NEW.title);
  END IF;
  RETURN NEW;
END;
$$;

-- Update update_updated_at function
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;