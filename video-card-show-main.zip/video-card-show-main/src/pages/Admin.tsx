import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Loader2, Plus, Trash2, Edit } from "lucide-react";
import { z } from "zod";

const postSchema = z.object({
  title: z.string().min(1, "Title is required").max(200, "Title too long"),
  video_links: z.array(z.string().url("Invalid video URL")).min(1, "At least one video link required"),
});

interface Post {
  id: string;
  title: string;
  thumbnail_url: string;
  video_links: string[];
  slug: string;
}

export default function Admin() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [posts, setPosts] = useState<Post[]>([]);
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  
  const [formData, setFormData] = useState({
    title: "",
    video_links: [""],
  });
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState<string>("");

  useEffect(() => {
    checkAdmin();
  }, []);

  const checkAdmin = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      toast.error("Please login first");
      navigate("/auth");
      return;
    }

    const { data } = await supabase
      .from("admins")
      .select("id")
      .eq("id", session.user.id)
      .single();

    if (!data) {
      toast.error("Access denied. Admin only.");
      navigate("/");
      return;
    }

    setIsAdmin(true);
    fetchPosts();
  };

  const fetchPosts = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("posts")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Error fetching posts");
    } else {
      setPosts((data || []).map(post => ({
        ...post,
        video_links: post.video_links as string[]
      })));
    }
    setLoading(false);
  };

  const handleAddVideoLink = () => {
    setFormData({
      ...formData,
      video_links: [...formData.video_links, ""],
    });
  };

  const handleRemoveVideoLink = (index: number) => {
    const newLinks = formData.video_links.filter((_, i) => i !== index);
    setFormData({ ...formData, video_links: newLinks });
  };

  const handleVideoLinkChange = (index: number, value: string) => {
    const newLinks = [...formData.video_links];
    newLinks[index] = value;
    setFormData({ ...formData, video_links: newLinks });
  };

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error("Please select an image file");
        return;
      }
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast.error("Image must be less than 5MB");
        return;
      }
      setThumbnailFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setThumbnailPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      // Validate form data
      const validatedData = postSchema.parse({
        title: formData.title.trim(),
        video_links: formData.video_links.filter(link => link.trim() !== "").map(link => link.trim()),
      });

      // Check if thumbnail is provided
      if (!editingPost && !thumbnailFile) {
        toast.error("Please select a thumbnail image");
        setSubmitting(false);
        return;
      }

      let thumbnailUrl = editingPost?.thumbnail_url || "";

      // Upload thumbnail if new file is selected
      if (thumbnailFile) {
        const fileExt = thumbnailFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('post-thumbnails')
          .upload(filePath, thumbnailFile, {
            cacheControl: '3600',
            upsert: false
          });

        if (uploadError) {
          toast.error("Failed to upload thumbnail");
          throw uploadError;
        }

        const { data: { publicUrl } } = supabase.storage
          .from('post-thumbnails')
          .getPublicUrl(filePath);

        thumbnailUrl = publicUrl;
      }

      if (editingPost) {
        const { error } = await supabase
          .from("posts")
          .update({
            title: validatedData.title,
            thumbnail_url: thumbnailUrl,
            video_links: validatedData.video_links,
          })
          .eq("id", editingPost.id);

        if (error) throw error;
        toast.success("Post updated successfully!");
      } else {
        const { error } = await supabase
          .from("posts")
          .insert({
            title: validatedData.title,
            thumbnail_url: thumbnailUrl,
            video_links: validatedData.video_links,
            slug: "",
          });

        if (error) throw error;
        toast.success("Post created successfully!");
      }

      setFormData({ title: "", video_links: [""] });
      setThumbnailFile(null);
      setThumbnailPreview("");
      setEditingPost(null);
      fetchPosts();
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      } else {
        toast.error("Failed to save post");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = (post: Post) => {
    setEditingPost(post);
    setFormData({
      title: post.title,
      video_links: post.video_links,
    });
    setThumbnailPreview(post.thumbnail_url);
    setThumbnailFile(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this post?")) return;

    const { error } = await supabase.from("posts").delete().eq("id", id);

    if (error) {
      toast.error("Failed to delete post");
    } else {
      toast.success("Post deleted successfully!");
      fetchPosts();
    }
  };

  const handleCancelEdit = () => {
    setEditingPost(null);
    setFormData({ title: "", video_links: [""] });
    setThumbnailFile(null);
    setThumbnailPreview("");
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex justify-center items-center h-[calc(100vh-4rem)]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>

        {/* Add/Edit Post Form */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>{editingPost ? "Edit Post" : "Add New Post"}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Post Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Enter post title"
                  required
                  maxLength={200}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="thumbnail">Thumbnail Image</Label>
                <Input
                  id="thumbnail"
                  type="file"
                  accept="image/*"
                  onChange={handleThumbnailChange}
                  className="cursor-pointer"
                />
                <p className="text-xs text-muted-foreground">
                  Max size: 5MB. Supported formats: JPG, PNG, WebP, GIF
                </p>
                {thumbnailPreview && (
                  <div className="mt-2 border rounded-lg overflow-hidden">
                    <img
                      src={thumbnailPreview}
                      alt="Thumbnail preview"
                      className="w-full h-48 object-cover"
                    />
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Video Links</Label>
                  <Button type="button" size="sm" onClick={handleAddVideoLink} variant="outline">
                    <Plus className="h-4 w-4 mr-1" />
                    Add Link
                  </Button>
                </div>
                
                {formData.video_links.map((link, index) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      type="url"
                      value={link}
                      onChange={(e) => handleVideoLinkChange(index, e.target.value)}
                      placeholder="https://youtube.com/embed/..."
                      required
                      maxLength={500}
                    />
                    {formData.video_links.length > 1 && (
                      <Button
                        type="button"
                        size="icon"
                        variant="destructive"
                        onClick={() => handleRemoveVideoLink(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Button type="submit" disabled={submitting} className="flex-1">
                  {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {editingPost ? "Update Post" : "Create Post"}
                </Button>
                {editingPost && (
                  <Button type="button" variant="outline" onClick={handleCancelEdit}>
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Posts List */}
        <Card>
          <CardHeader>
            <CardTitle>All Posts ({posts.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : posts.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No posts yet</p>
            ) : (
              <div className="space-y-4">
                {posts.map((post) => (
                  <div
                    key={post.id}
                    className="flex items-center gap-4 p-4 border border-border rounded-lg hover:border-primary/50 transition-colors"
                  >
                    <img
                      src={post.thumbnail_url}
                      alt={post.title}
                      className="w-24 h-16 object-cover rounded"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold">{post.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {post.video_links.length} video{post.video_links.length !== 1 && "s"}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => handleEdit(post)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => handleDelete(post.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
