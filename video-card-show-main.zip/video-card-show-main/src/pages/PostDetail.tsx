import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { Loader2 } from "lucide-react";
import { Card } from "@/components/ui/card";

interface Post {
  id: string;
  title: string;
  thumbnail_url: string;
  video_links: string[];
  slug: string;
}

interface SidebarPost {
  id: string;
  title: string;
  thumbnail_url: string;
  slug: string;
}

export default function PostDetail() {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<Post | null>(null);
  const [sidebarPosts, setSidebarPosts] = useState<SidebarPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (slug) {
      fetchPost();
      fetchSidebarPosts();
    }
  }, [slug]);

  const fetchPost = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("posts")
      .select("*")
      .eq("slug", slug)
      .single();

    if (error) {
      console.error("Error fetching post:", error);
    } else {
      setPost({
        ...data,
        video_links: data.video_links as string[]
      });
    }
    setLoading(false);
  };

  const fetchSidebarPosts = async () => {
    const { data, error } = await supabase
      .from("posts")
      .select("id, title, thumbnail_url, slug")
      .neq("slug", slug)
      .order("created_at", { ascending: false })
      .limit(3);

    if (error) {
      console.error("Error fetching sidebar posts:", error);
    } else {
      setSidebarPosts(data || []);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex justify-center items-center h-[calc(100vh-4rem)]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Post not found</h1>
          <Link to="/" className="text-primary hover:underline">
            Back to home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content */}
          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-bold mb-6">{post.title}</h1>

            {/* Thumbnail */}
            <div className="mb-6 rounded-lg overflow-hidden">
              <img
                src={post.thumbnail_url}
                alt={post.title}
                className="w-full h-auto"
              />
            </div>

            {/* Video Links */}
            <div className="space-y-6">
              {post.video_links && post.video_links.length > 0 ? (
                post.video_links.map((link, index) => (
                  <Card key={index} className="p-4">
                    <h3 className="font-semibold mb-3">Video {index + 1}</h3>
                    <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                      <iframe
                        src={link}
                        className="w-full h-full"
                        allowFullScreen
                        title={`${post.title} - Video ${index + 1}`}
                      />
                    </div>
                  </Card>
                ))
              ) : (
                <p className="text-muted-foreground">No videos available</p>
              )}
            </div>
          </div>

          {/* Sidebar - Watch Next */}
          <aside className="w-full lg:w-[350px] flex flex-col gap-4">
            <h3 className="text-lg font-semibold mb-2">Watch Next</h3>

            {sidebarPosts.length > 0 ? (
              sidebarPosts.map((sidePost) => (
                <Link
                  key={sidePost.id}
                  to={`/post/${sidePost.slug}`}
                  className="flex flex-col border border-border rounded-lg overflow-hidden hover:scale-[1.02] hover:border-primary/50 transition-all duration-200"
                >
                  <div className="relative h-[200px] overflow-hidden">
                    <img
                      src={sidePost.thumbnail_url}
                      className="object-cover w-full h-full"
                      alt={sidePost.title}
                    />
                    <div className="absolute inset-0 overlay-gradient opacity-0 hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="p-3 bg-card">
                    <p className="text-sm font-medium line-clamp-2">{sidePost.title}</p>
                  </div>
                </Link>
              ))
            ) : (
              <p className="text-muted-foreground text-sm">No more posts available</p>
            )}
          </aside>
        </div>
      </main>
    </div>
  );
}
